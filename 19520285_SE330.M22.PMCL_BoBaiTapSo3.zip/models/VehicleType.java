package models;

enum VehicleType {
    Bicycle,
    Car,
    Bike,
    Truck
}
